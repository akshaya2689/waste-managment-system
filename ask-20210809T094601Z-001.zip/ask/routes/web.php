<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/address-list', 'AddressController@index')->name('address_list');

Route::get('/address/add', 'AddressController@add')->name('address_add');

Route::post('/address/create', 'AddressController@create')->name('address_create');

Route::delete('/address/{rid}', 'AddressController@delete')->name('address_delete');

Route::get('/pickup-list', 'PickupController@index')->name('pickup_list');

Route::get('/pickup/add', 'PickupController@add')->name('pickup_add');

Route::post('/pickup/create', 'PickupController@create')->name('pickup_create');

Route::get('/cart-list', 'CartController@index')->name('cart_list');

Route::post('/cart/create', 'CartController@create')->name('cart_create');

Route::post('/payment/post', 'PaymentController@post')->name('payment_post');

Route::get('/payment/success', 'PaymentController@success')->name('payment_success');

Route::get('/orders-list', 'OrdersController@index')->name('order_list');

Route::get('/about', function () {
    return view('about');
})->name('about');