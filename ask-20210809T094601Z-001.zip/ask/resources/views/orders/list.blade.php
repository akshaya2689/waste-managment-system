@extends('layouts.app')

@section('content')

    <!-- Current orders -->
    @if (count($orders) > 0)
        <div class="tile is-ancestor">
            @foreach ($orders as $order)
                @foreach ($order->items()->get() as $item)
                    <div class="tile is-parent">
                        <article class="tile is-child box">
                            <p class="title">{{ $item->name }}</p>
                            <p class="subtitle">
                                {{ $item->line1 }} <br />
                                {{ $item->line2 }} <br />
                                {{ $item->city }} <br />
                                {{ $item->state }} <br />
                            </p>
                        </article>
                    </div>
                @endforeach
            @endforeach
        </div>
    @endif

@endsection