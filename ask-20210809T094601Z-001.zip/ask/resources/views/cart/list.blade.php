@extends('layouts.app')

@section('content')
    <h1>Cart</h1>
    <div class="container">
        <div class="row">
            <label for="line1" class="col-sm-3 control-label">Pick On</label>

            <div class="col-sm-6">
                <input type='text' class="flatpickr form-control" id='datetimepicker4' />
            </div>
        </div>
    </div>

    <!-- Current addresses -->
    @if ($items)
        <div class="tile is-ancestor">
            @foreach ($items as $item)
                <div class="tile is-parent">
                    <article class="tile is-child box">
                        <p class="title">{{ $item->name }}</p>
                        <p class="subtitle">
                            {{ $item->line1 }} <br />
                            {{ $item->line2 }} <br />
                            {{ $item->city }} <br />
                            {{ $item->state }} <br />
                        </p>
                    </article>
                </div>
            @endforeach
        </div>

        <!--  Create an Order using Orders API. (https://razorpay.com/docs/payment-gateway/orders/integration/#step-1-create-an-order -->
        <form action="{{ route('payment_post') }}" method="POST">
            <script src="https://checkout.razorpay.com/v1/checkout.js" 
                data-key="rzp_test_Alcsi9GiDHMNZt" 
                data-amount="500" 
                data-currency="INR" 
                data-order_id="{{ $order_id }}"
                data-buttontext="Pay with Razorpay" 
                data-name="Waste Collection"    
                data-description="Waste Collection Fee"
                data-image="https://example.com/your_logo.jpg"    
                data-prefill.name="{{ Auth::user()->name }}"    
                data-prefill.email="{{ Auth::user()->email }}"    
                data-prefill.contact="9999999999"    
                data-theme.color="#F37254">
            </script>
            {{ csrf_field() }}
        </form>

    @endif

@endsection

@section('scripts')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script type="text/javascript">
        $(function () {
            flatpickr("#datetimepicker4", {
                enable: [ 
                    @foreach ($pickups as $pickup)
                        "{{ $pickup }}",
                    @endforeach
                ]
            });
        })
    </script>
@stop