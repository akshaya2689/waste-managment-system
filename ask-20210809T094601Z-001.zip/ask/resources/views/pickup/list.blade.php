@extends('layouts.app')

@section('content')

    Pickup List

@endsection