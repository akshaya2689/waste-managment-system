@extends('layouts.app')

@section('content')

<!-- Display Validation Errors -->
@include('common.errors')

<form action="{{ route('pickup_create') }}" method="POST" class="form-horizontal">
    {{ csrf_field() }}

    <div class="field">
        <label class="label">{{ __('Pickup On') }}</label>
        <div class="control">
            <input class="input @error('pickup_on') is-danger @enderror" type="text" placeholder="Pickup On" id="pickup_on" name="pickup_on" value="{{ old('pickup_on') }}">
            <a class="input-button" title="toggle" data-toggle>
                <i class="icon-calendar"></i>
            </a>

            <a class="input-button" title="clear" data-clear>
                <i class="icon-close"></i>
            </a>
            @error('pickup_on')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control">
            <button class="button is-link">{{ __('Add') }}</button>
        </div>
        <div class="control">
            <a class="button is-link is-light " href="{{ route('pickup_list') }}">
                {{ __('Cancel') }}
            </a>
        </div>
    </div>

</form>

@endsection

@section('scripts')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script type="text/javascript">
        $(function () {
            flatpickr("#pickup_on", {
                minDate: "today"
            });
        })
    </script>
@stop