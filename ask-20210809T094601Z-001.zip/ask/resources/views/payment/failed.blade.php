@extends('layouts.app')

@section('content')
    Payment Failed
@endsection