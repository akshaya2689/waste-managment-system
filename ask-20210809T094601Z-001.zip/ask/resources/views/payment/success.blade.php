@extends('layouts.app')

@section('content')
    Payment Success

    <a href="{{ route('order_list') }}">View Previous Orders</a>
@endsection