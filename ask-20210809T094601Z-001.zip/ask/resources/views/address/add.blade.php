@extends('layouts.app')

@section('content')

<!-- Display Validation Errors -->
@include('common.errors')

<form action="{{ route('address_create') }}" method="POST" class="form-horizontal">
    {{ csrf_field() }}

    <div class="field">
        <label class="label">{{ __('Name') }}</label>
        <div class="control">
            <input class="input @error('name') is-danger @enderror" type="text" placeholder="Name" id="name" name="name" value="{{ old('name') }}">
            @error('name')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('Address Line 1') }}</label>
        <div class="control">
            <input class="input @error('line1') is-danger @enderror" type="text" placeholder="Name" id="line1" name="line1" value="{{ old('line1') }}">
            @error('line1')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('Address Line 2') }}</label>
        <div class="control">
            <input class="input @error('line2') is-danger @enderror" type="text" placeholder="Address Line 2" id="line2" name="line2" value="{{ old('line2') }}">
            @error('line2')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>


    <div class="field">
        <label class="label">{{ __('City') }}</label>
        <div class="control">
            <input class="input @error('city') is-danger @enderror" type="text" placeholder="City" id="city" name="city" value="{{ old('city') }}">
            @error('city')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('State') }}</label>
        <div class="control">
            <input class="input @error('state') is-danger @enderror" type="text" placeholder="State" id="state" name="state" value="{{ old('state') }}">
            @error('state')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('Country') }}</label>
        <div class="control">
            <input class="input @error('country') is-danger @enderror" type="text" placeholder="country" id="country" name="country" value="{{ old('country') }}">
            @error('country')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('PIN Code') }}</label>
        <div class="control">
            <input class="input @error('pin') is-danger @enderror" type="text" placeholder="pin" id="pin" name="pin" value="{{ old('pin') }}">
            @error('pin')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control">
            <button class="button is-link">{{ __('Add') }}</button>
        </div>
        <div class="control">
            <a class="button is-link is-light " href="{{ route('address_list') }}">
                {{ __('Cancel') }}
            </a>
        </div>
    </div>

</form>

@endsection