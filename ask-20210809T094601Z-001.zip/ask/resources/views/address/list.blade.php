@extends('layouts.app')

@section('content')

    <!-- Current addresses -->
    @if (count($addresses) > 0)
        <form method="POST" action="{{ route('cart_create') }}">
            {{ csrf_field() }}
            <div class="tile is-ancestor">
                @foreach ($addresses as $address)
                    <div class="tile is-parent">
                        <article class="tile is-child box">
                            <p class="title">{{ $address->name }}</p>
                            <p class="subtitle">
                                {{ $address->line1 }} <br />
                                {{ $address->line2 }} <br />
                                {{ $address->city }} <br />
                                {{ $address->state }} <br />
                            </p>
                            <div class="content">
                                <label>
                                    <input type="checkbox" name="address[]" value="{{ $address->id }}" />
                                    Pick From here
                                </label>
                            </div>
                        </article>
                    </div>
                @endforeach
            </div>

            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-link">{{ __('Add') }}</button>
                </div>
            </div>

        </form>
    @endif

@endsection