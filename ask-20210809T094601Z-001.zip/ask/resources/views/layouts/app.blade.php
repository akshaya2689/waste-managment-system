<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.min.css">
        <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    </head>
    <body>
        <section class="section">
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                <img src="/images/logoo.png" width="112" height="100">
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/">
                        Home
                    </a>

                    <a class="navbar-item" href="{{ route('about') }}">
                        About 
                    </a>
                    
                </div>

                <div class="navbar-end">
                    @guest
                        <div class="navbar-item">
                            <div class="buttons">
                                @if (Route::has('register'))
                                    <a class="button is-primary" href="{{ route('register') }}">
                                        <strong>{{ __('Register') }}</strong>
                                    </a>
                                @endif
                                <a class="button is-light" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </div>
                        </div>
                    @else
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                {{ Auth::user()->name }}
                            </a>

                            <div class="navbar-dropdown">
                                <a class="navbar-item" href="{{ route('address_add') }}">
                                    Add Address
                                </a>
                                <a class="navbar-item" href="{{ route('address_list') }}">
                                    Address List
                                </a>
                                <a class="navbar-item" href="{{ route('order_list') }}">
                                    Orders List
                                </a>
                                <a class="navbar-item" href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    @csrf
                                </form>
                                <hr class="navbar-divider">
                                 <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    @endguest
                </div>
            </div>
            </nav>
            <div class="container">
                @yield('content')
            </div>
        </section>
    </body>

    @yield('scripts');

</html>
