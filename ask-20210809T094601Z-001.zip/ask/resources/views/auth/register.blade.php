@extends('layouts.app')

@section('content')

{{ __('Register') }}

<form method="POST" action="{{ route('register') }}">
    @csrf

    <div class="field">
        <label class="label">{{ __('Name') }}</label>
        <div class="control">
            <input class="input @error('name') is-danger @enderror" type="text" placeholder="Name" id="name" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
            @error('name')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('E-Mail Address') }}</label>
        <div class="control has-icons-left has-icons-right">
            <input class="input @error('email') is-danger @enderror" type="email" placeholder="Email" id="email" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
            @error('email')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('Password') }}</label>
        <div class="control has-icons-left has-icons-right">
            <input class="input @error('password') is-danger @enderror" type="password" placeholder="Password" id="password" name="password" required autocomplete="new-password">
            @error('password')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field">
        <label class="label">{{ __('Confirm Password') }}</label>
        <div class="control has-icons-left has-icons-right">
            <input class="input @error('password') is-danger @enderror" type="password" placeholder="Password" id="password-confirm" name="password_confirmation" required autocomplete="new-password">
            @error('password')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control">
            <button class="button is-link">{{ __('Register') }}</button>
        </div>
    </div>

</form>

@endsection