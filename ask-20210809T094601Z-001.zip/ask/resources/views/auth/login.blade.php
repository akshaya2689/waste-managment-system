@extends('layouts.app')

@section('content')
<div class="">{{ __('Login') }}</div>

<form method="POST" action="{{ route('login') }}">
    @csrf

    <div class="field">
        <label class="label">{{ __('E-Mail Address') }}</label>
        <div class="control has-icons-left has-icons-right">
            <input class="input @error('email') is-danger @enderror" type="email" placeholder="Email" id="email" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
            @error('email')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>


    <div class="field">
        <label class="label">{{ __('Password') }}</label>
        <div class="control has-icons-left has-icons-right">
            <input class="input @error('password') is-danger @enderror" type="password" placeholder="Password" id="password" name="password" required autocomplete="current-password">
            @error('password')
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger">{{ $message }}</p>
            @enderror
        </div>
    </div>


    <div class="field">
        <div class="control">
            <label class="checkbox">
                <input type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                {{ __('Remember Me') }}
            </label>
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control">
            <button class="button is-link">{{ __('Login') }}</button>
        </div>
        <div class="control">
            @if (Route::has('password.request'))
            <a class="button is-link is-light " href="{{ route('password.request') }}">
                {{ __('Forgot Your Password?') }}
            </a>
            @endif
        </div>
    </div>


</form>
@endsection