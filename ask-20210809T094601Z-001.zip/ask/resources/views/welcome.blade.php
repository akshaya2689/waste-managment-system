@extends('layouts.app')

@section('content')
    <h1 class="title">
        <a class="navbar-brand" href="{{ url('/') }}">
            {{ config('app.name', 'Laravel') }}
        </a>
    </h1>
    <p class="subtitle">
        <strong>Waste Collection</strong>!
    </p>
@endsection