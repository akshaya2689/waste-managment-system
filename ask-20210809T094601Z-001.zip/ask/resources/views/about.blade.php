@extends('layouts.app')

@section('content')

    About

@endsection