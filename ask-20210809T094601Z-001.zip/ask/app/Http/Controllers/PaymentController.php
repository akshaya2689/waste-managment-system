<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Razorpay\Api\Api;
use App\Cart;
use App\Order;
use App\OrderItem;

class PaymentController extends Controller
{
    public function post(Request $request)
    {
        $api = new Api(getenv('RAZOR_PAY_KEY_ID'), getenv('RAZOR_PAY_KEY_SECRET'));
        $attributes  = [
            'razorpay_signature' => $request->razorpay_signature,
            'razorpay_payment_id' => $request->razorpay_payment_id,
            'razorpay_order_id' => $request->razorpay_order_id,
        ];
        try {
            // $rorder  = $api->utility->verifyPaymentSignature($attributes);

            $cart = Cart::where([
                'user_id' => $request->user()->id,
                'order_id' => $request->razorpay_order_id,
            ])->first();

            $data = $cart->toArray();
            $data['razorpay_signature'] = $request->razorpay_signature;
            $data['razorpay_payment_id'] = $request->razorpay_payment_id;
            $data['razorpay_order_id'] = $request->razorpay_order_id;

            $order = new Order();
            $order->fill($data);            
            $order->save();

            $cart_items = $cart->items()->get();

            foreach ($cart_items as $item) {
                $oitem = new OrderItem();
                $data = $item->toArray();
                $data['order_id'] = $order->id;
                $oitem->fill($data);                
                $oitem->save();
            }
        } catch (\Exception $e) {
            return redirect('/payment/failed');
        }

        foreach ($cart_items as $item) {
            $item->delete();
        }

        $cart->delete();

        return redirect('/payment/success');
    }

    public function success()
    {
        return view('payment/success');
    }

    public function failed()
    {
        return view('payment/failed');
    }
}
