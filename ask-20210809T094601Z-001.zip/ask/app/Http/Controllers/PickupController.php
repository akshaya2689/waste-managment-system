<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Pickup;

class PickupController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $pickups = Pickup::orderBy('created_at', 'asc')->get();

        return view('pickup/list', [
            'pickups' => $pickups
        ]);
    }

    public function add(Request $request)
    {
        return view('pickup/add');
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pickup_on' => 'required',            
        ]);
    
        if ($validator->fails()) {
            return redirect('/pickup/add')
                ->withInput()
                ->withErrors($validator);
        }
    
        $pickup = new Pickup;
        $pickup->pickup_on = $request->pickup_on;
        $pickup->save();

        return redirect('/pickup-list');
    }

    public function delete(Request $request)
    {
        $pickup = Pickup::where('user_id', $request->user()->id)
            ->where('id', $request->id)
            ->first();
        $pickup->delete();

        return redirect('/pickup-list');
    }
}
