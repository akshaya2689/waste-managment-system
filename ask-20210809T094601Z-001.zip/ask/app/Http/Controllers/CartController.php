<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Address;
use App\Cart;
use App\CartItem;
use App\Pickup;
use Razorpay\Api\Api;

class CartController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $pickup_dates = [];

        $date = new \DateTime();
        $pickups = Pickup::where('pickup_on', '>', $date->format('Y-m-d'))->get();

        foreach ($pickups as $pickup)
        {
            $pickup_dates[] = $pickup->pickup_on;
        }

        $cart = Cart::firstOrCreate([
            'user_id' => $request->user()->id
        ]);

        $items = $cart->items()->get();
       
        $cart->amount = count($items) * getenv('AMOUNT');
        $cart->save();

        // Orders
        if (! $cart->order_id)
        {
            $api = new Api(getenv('RAZOR_PAY_KEY_ID'), getenv('RAZOR_PAY_KEY_SECRET'));
            $order  = $api->order->create(array('receipt' => $cart->id, 'amount' => $cart->amount, 'currency' => 'INR'));
            $cart->order_id = $order['id'];
            $cart->save();
        }        

        return view('cart/list', [
            'items' => $items,
            'pickups' => $pickup_dates,
            'order_id' => $cart->order_id,
        ]);

        return view('cart/list');
    }


    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'address' => 'required',
        ]);
    
        if ($validator->fails()) {
            return redirect('/address-list')
                ->withInput()
                ->withErrors($validator);
        }

        $addresses = Address::
            where('user_id', $request->user()->id)->
            whereIn('id', $request->address)->
            get();
        
        $cart = Cart::firstOrCreate([
            'user_id' => $request->user()->id
        ]);
        $cart->save();

        foreach ($addresses as $address) {
            $item = new CartItem();
            $data = $address->toArray();
            $item->cart_id = $cart->id;
            $item->address_id = $address->id;
            $item->fill($data);
            $item->save();
        }

        return redirect('/cart-list');
    }
}
