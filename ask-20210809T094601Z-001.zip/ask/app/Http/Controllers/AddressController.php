<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Address;

class AddressController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $addresses = Address::where('user_id', $request->user()->id)->orderBy('created_at', 'asc')->get();

        return view('address/list', [
            'addresses' => $addresses
        ]);
    }

    public function add(Request $request)
    {
        return view('address/add');
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'line1' => 'required',
            'city' => 'required',
            'state' => 'required',
            'country' => 'required',
            'pin' => 'required',
        ]);
    
        if ($validator->fails()) {
            return redirect('/address/add')
                ->withInput()
                ->withErrors($validator);
        }
    
        $address = new Address;
        $address->user_id = $request->user()->id;
        $address->name = $request->name;
        $address->line1 = $request->line1;
        $address->line2 = $request->line2;
        $address->city = $request->city;
        $address->state = $request->state;
        $address->country = $request->country;
        $address->pin = $request->pin;
        $address->save();

        return redirect('/address-list');
    }

    public function delete(Request $request)
    {
        $address = Address::where('user_id', $request->user()->id)
            ->first();
        $address->delete();

        return redirect('/address-list');
    }
}
