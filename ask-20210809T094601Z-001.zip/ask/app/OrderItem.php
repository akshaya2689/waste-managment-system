<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    protected $fillable = [
        'name',
        'line1',
        'line2',
        'city',
        'state',
        'country',
        'pin',
        'order_id'
    ];
}
