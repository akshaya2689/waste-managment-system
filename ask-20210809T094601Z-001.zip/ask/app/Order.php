<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'user_id',
        'pickup_on',
        'pickup_id',
        'amount',
        'razorpay_signature',
        'razorpay_payment_id',
        'razorpay_order_id',
    ];

    public function items()
    {
        return $this->hasMany('App\OrderItem');
    }
}
