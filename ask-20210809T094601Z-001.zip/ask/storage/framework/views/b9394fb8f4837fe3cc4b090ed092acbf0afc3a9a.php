<?php $__env->startSection('content'); ?>
    <h1 class="title">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </a>
    </h1>
    <p class="subtitle">
        <strong>Waste Collection</strong>!
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chirakkal/ask/resources/views/welcome.blade.php ENDPATH**/ ?>