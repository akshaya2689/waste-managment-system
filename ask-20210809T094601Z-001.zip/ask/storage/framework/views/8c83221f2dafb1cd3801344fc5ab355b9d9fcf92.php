<?php $__env->startSection('content'); ?>

    Pickup List

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/hari/8345a046-99fd-4905-b4e1-813be6128914/projects/akshaya/waste-collection/resources/views/pickup/list.blade.php ENDPATH**/ ?>