<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.min.css">
        <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    </head>
    <body>
        <section class="section">
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                <img src="https://bulma.io/images/bulma-logo.png" width="112" height="28">
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item">
                        Home
                    </a>

                    <a class="navbar-item">
                        Documentation
                    </a>

                    
                </div>

                <div class="navbar-end">
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="navbar-item">
                            <div class="buttons">
                                <?php if(Route::has('register')): ?>
                                    <a class="button is-primary" href="<?php echo e(route('register')); ?>">
                                        <strong><?php echo e(__('Register')); ?></strong>
                                    </a>
                                <?php endif; ?>
                                <a class="button is-light" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="navbar-dropdown">
                                <a class="navbar-item" href="<?php echo e(route('address_add')); ?>">
                                    Add Address
                                </a>
                                <a class="navbar-item" href="<?php echo e(route('address_list')); ?>">
                                    Address List
                                </a>                            
                                <a class="navbar-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                                <hr class="navbar-divider">
                                <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            </nav>
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </body>

    <?php echo $__env->yieldContent('scripts'); ?>;

</html>
<?php /**PATH /media/hari/8345a046-99fd-4905-b4e1-813be6128914/projects/akshaya/waste-collection/resources/views/layouts/app.blade.php ENDPATH**/ ?>