
    Hello world from view

<?php /**PATH /home/chirakkal/ask/resources/views/hello.blade.php ENDPATH**/ ?>