<?php $__env->startSection('content'); ?>
    Payment Success

    <a href="<?php echo e(route('order_list')); ?>">View Previous Orders</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chirakkal/ask/resources/views/payment/success.blade.php ENDPATH**/ ?>