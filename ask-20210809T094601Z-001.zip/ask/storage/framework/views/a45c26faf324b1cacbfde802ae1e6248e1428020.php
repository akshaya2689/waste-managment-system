<?php $__env->startSection('content'); ?>

    <!-- Current orders -->
    <?php if(count($orders) > 0): ?>
        <div class="tile is-ancestor">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $order->items()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tile is-parent">
                        <article class="tile is-child box">
                            <p class="title"><?php echo e($item->name); ?></p>
                            <p class="subtitle">
                                <?php echo e($item->line1); ?> <br />
                                <?php echo e($item->line2); ?> <br />
                                <?php echo e($item->city); ?> <br />
                                <?php echo e($item->state); ?> <br />
                            </p>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chirakkal/ask/resources/views/orders/list.blade.php ENDPATH**/ ?>