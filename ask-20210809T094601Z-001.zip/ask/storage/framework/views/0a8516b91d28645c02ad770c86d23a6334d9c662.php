<?php $__env->startSection('content'); ?>

    <!-- Bootstrap Boilerplate... -->

    <div class="panel-body">
        <!-- Display Validation Errors -->
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <form action="/address/create" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            
            <div class="form-group">
                <label for="line1" class="col-sm-3 control-label">Address Line 1</label>

                <div class="col-sm-6">
                    <input type="text" name="line1" id="line1" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label for="line2" class="col-sm-3 control-label">Address Line 2</label>

                <div class="col-sm-6">
                    <input type="text" name="line2" id="line2" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label for="city" class="col-sm-3 control-label">City</label>

                <div class="col-sm-6">
                    <input type="text" name="city" id="city" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label for="state" class="col-sm-3 control-label">State</label>

                <div class="col-sm-6">
                    <input type="text" name="state" id="state" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label for="pincode" class="col-sm-3 control-label">PIN Code</label>

                <div class="col-sm-6">
                    <input type="text" name="pincode" id="pincode" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-6">
                    <button type="submit" class="btn btn-default">
                        <i class="fa fa-plus"></i> Add Address
                    </button>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/hari/8345a046-99fd-4905-b4e1-813be6128914/projects/akshaya/waste-collection/resources/views/address/create.blade.php ENDPATH**/ ?>