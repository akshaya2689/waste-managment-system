<?php $__env->startSection('content'); ?>

    <!-- Current addresses -->
    <?php if(count($addresses) > 0): ?>
        <form method="POST" action="<?php echo e(route('cart_create')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="tile is-ancestor">
                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tile is-parent">
                        <article class="tile is-child box">
                            <p class="title"><?php echo e($address->name); ?></p>
                            <p class="subtitle">
                                <?php echo e($address->line1); ?> <br />
                                <?php echo e($address->line2); ?> <br />
                                <?php echo e($address->city); ?> <br />
                                <?php echo e($address->state); ?> <br />
                            </p>
                            <div class="content">
                                <label>
                                    <input type="checkbox" name="address[]" value="<?php echo e($address->id); ?>" />
                                    Pick From here
                                </label>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-link"><?php echo e(__('Add')); ?></button>
                </div>
            </div>

        </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/hari/8345a046-99fd-4905-b4e1-813be6128914/projects/akshaya/waste-collection/resources/views/address/list.blade.php ENDPATH**/ ?>