<?php $__env->startSection('content'); ?>

<!-- Display Validation Errors -->
<?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="/pickup/create" method="POST" class="form-horizontal">
    <?php echo e(csrf_field()); ?>


    <div class="field">
        <label class="label"><?php echo e(__('Pickup On')); ?></label>
        <div class="control">
            <input class="input <?php $__errorArgs = ['pickup_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="Pickup On" id="pickup_on" name="pickup_on" value="<?php echo e(old('pickup_on')); ?>">
            <a class="input-button" title="toggle" data-toggle>
                <i class="icon-calendar"></i>
            </a>

            <a class="input-button" title="clear" data-clear>
                <i class="icon-close"></i>
            </a>
            <?php $__errorArgs = ['pickup_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
            </span>
            <span class="icon is-small is-right">
                <i class="fas fa-exclamation-triangle"></i>
            </span>
            <p class="help is-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control">
            <button class="button is-link"><?php echo e(__('Add')); ?></button>
        </div>
        <div class="control">
            <a class="button is-link is-light " href="<?php echo e(route('pickup_list')); ?>">
                <?php echo e(__('Cancel')); ?>

            </a>
        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script type="text/javascript">
        $(function () {
            flatpickr("#pickup_on", {
                minDate: "today"
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/hari/8345a046-99fd-4905-b4e1-813be6128914/projects/akshaya/waste-collection/resources/views/pickup/add.blade.php ENDPATH**/ ?>