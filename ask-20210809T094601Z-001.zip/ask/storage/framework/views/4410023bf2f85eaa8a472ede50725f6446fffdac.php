<?php $__env->startSection('content'); ?>
    <h1>Cart</h1>    
    <div class="container">
        <div class="row">
            <label for="line1" class="col-sm-3 control-label">Pick On</label>

            <div class="col-sm-6">
                <input type='text' class="flatpickr form-control" id='datetimepicker4' />
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script type="text/javascript">
        $(function () {
            flatpickr("#datetimepicker4", {
                enable: [ 
                    <?php $__currentLoopData = $pickups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pickup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($pickup); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/hari/8345a046-99fd-4905-b4e1-813be6128914/projects/akshaya/waste-collection/resources/views/cart.blade.php ENDPATH**/ ?>