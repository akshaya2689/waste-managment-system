<?php $__env->startSection('content'); ?>

    About

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chirakkal/ask/resources/views/about.blade.php ENDPATH**/ ?>